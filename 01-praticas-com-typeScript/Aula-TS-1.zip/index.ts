const login = (
  identification: number | string,
  password: number | string
): boolean | string => {
  const identificationMock = "alo@gama.com";
  const passwordMock = "aloSenha1";

  if (identification !== identificationMock) {
    return "Usuario não existe";
  }

  return identification == identificationMock && password == passwordMock;
};

console.log(login("alo@gama.com", "aloSenha1"));

console.log(login("teste", "123"));
console.log(login("alo@gama.com", "123"));

type Receita = {
  titulo: string;
  video?: string;
  ingredientes: string[];
};

const cachorroQuente: Receita = {
  titulo: "Cachorro quente",
  ingredientes: ["Pão", "salsicha"],
};

type Produto = {
  nome: string;
  codigoBarras: number;
  preco: number;
  desconto?: number;
};

const Ps: Produto[] = [
  {
    nome: "Brinquedo",
    codigoBarras: 1231241212312,
    preco: 39.99,
    desconto: 2.99,
  },
  {
    nome: "Notebook",
    codigoBarras: 1223232112,
    preco: 3300.9,
  },
];

// usando tuple
const produto: [string, number, number, number?] = [
  "Brinquedo",
  1231241212312,
  39.99,
];
