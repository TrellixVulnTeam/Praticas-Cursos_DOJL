module.exports = {
  key: "la-vie-gama-2022",
};
