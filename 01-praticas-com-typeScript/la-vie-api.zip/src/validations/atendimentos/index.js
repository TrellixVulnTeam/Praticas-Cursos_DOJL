const create = require("./create");
const getOne = require("./getOne");

const AtendimentoValidation = {
  create,
  getOne,
};

module.exports = AtendimentoValidation;
