const login = require("./login");

const loginValidation = {
  login,
};

module.exports = loginValidation;
